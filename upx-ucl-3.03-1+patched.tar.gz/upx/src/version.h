#define UPX_VERSION_HEX         0x030300        /* 03.03.00 */
#define UPX_VERSION_STRING      "3.03"
#define UPX_VERSION_STRING4     "3.03"
#define UPX_VERSION_DATE        "Apr 27th 2008"
#define UPX_VERSION_DATE_ISO    "2008-04-27"
#define UPX_VERSION_YEAR        "2008"
