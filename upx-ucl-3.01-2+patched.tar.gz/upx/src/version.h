#define UPX_VERSION_HEX         0x030100        /* 03.01.00 */
#define UPX_VERSION_STRING      "3.01"
#define UPX_VERSION_STRING4     "3.01"
#define UPX_VERSION_DATE        "Jul 31st 2007"
#define UPX_VERSION_DATE_ISO    "2007-07-31"
#define UPX_VERSION_YEAR        "2007"
