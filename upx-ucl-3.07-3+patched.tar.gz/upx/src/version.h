#define UPX_VERSION_HEX         0x030700        /* 03.07.00 */
#define UPX_VERSION_STRING      "3.07"
#define UPX_VERSION_STRING4     "3.07"
#define UPX_VERSION_DATE        "Sep 08th 2010"
#define UPX_VERSION_DATE_ISO    "2010-09-08"
#define UPX_VERSION_YEAR        "2010"
